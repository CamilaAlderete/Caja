/*
	Eric Ruiz Diaz
	Ruben Izembrandt
	G09
*/

public class Node 
{
	public char label;
	public boolean visited=false;
	public Node(char l)
	{
		this.label=l;
	}
}