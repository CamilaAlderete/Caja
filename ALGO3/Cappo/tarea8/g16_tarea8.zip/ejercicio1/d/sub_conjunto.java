/* 
	G16
	Eric RuizDiaz
	Luis Pereira

	Trabajo hecho con la participacion y cooperacion de G03
*/
class sub_conjunto 
{ 
    public int representante, rango; 
}; 