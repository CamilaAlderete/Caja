//1/03/2018
//El trabajo fue hecho por Ruben Izembrandt y Eric Ruiz Diaz
//Ejercicio 3.b)

import java.util.Scanner;

public class Conjuntos {
        
    static Lista[] miVector;//se declara un vector estatico tipo lista
    static Scanner reader = new Scanner(System.in);//se declara un scanner
    static String dato;
    static int n,x,i;
    
    public class Nodo{//tipo de tad para la lista enlazada
        public Nodo sig;
        public String valor;
        int tipo_dato;
    }
    static class Lista{//dode guardar las raices de todos los conjuntos
         public Nodo raiz;  
    }

    
    Nodo cargarDato(Nodo raiz ){

       raiz =agregar(raiz);//se guarda en la raiz el ultimo dato en procesar
        
       return raiz;//se retorna la raiz
    }
    
    Nodo agregar(Nodo raiz){
    
        int j = i + 1;//para imprimir al usuario
        
        while(x == 0){    

            System.out.println("Inserte un dato para la lista " + j+ "\nIngrese 'finish' para dejar de cargar");
            dato = reader.nextLine();  
        
            if (!(dato.equals("finish"))){//si el dato distinto a la clave finish
                Nodo temp= new Nodo();//se crea un nodo temporal
                temp.valor=dato;

                if(raiz==null){//crea el primer nodo
                    temp.sig=null;
                }
            
                else{//inserta un nuevo nodo antes del primer nodo

                    temp.sig=raiz;
                }
            
                    raiz=temp;
            }
            else {
                x = 1;//se deja de cargar datos
            }
        }

        return raiz;
    }
    

    void pertenencia (Nodo raiz,String valorBuscado, int nro){
        
        nro++;//para imprimir al usuario
        Nodo siguiente=raiz;//se guarda el nodo raiz en siguiente
        while((siguiente.sig!=null)&&(!siguiente.valor.equals(valorBuscado))){//mientras siguiente sea distinto al valor buscado
            siguiente=siguiente.sig;//siguiente es igual al siguiente nodo

        }
        if(siguiente.valor.equals(valorBuscado)){
            System.out.println("el elemento '"+ valorBuscado+"' pertenece a la lista " + nro);//si se encontro se avisa al usuario
        }
        else {
            System.out.println("El elemento '"+ valorBuscado + "' no pertenece a al lista " + nro );//si no tambien se avisa con un mensaje triste
        }
    }
    
     void borrar(Nodo raiz, String valor){
        Nodo intermedio=raiz;//se declara un nodo intermedio y guarda el valor de raiz
        Nodo previo=raiz;//previo tambien
        while( (intermedio.sig!=null) && ( ! (intermedio.valor.equals(valor)) ) ){//mientras no se encuentre el valor
            previo=intermedio;//previo es igual al actual
            intermedio=intermedio.sig;//actual es igual al siguiente
            
        }
        previo.sig=intermedio.sig;//se borra el dato encontrado
     }

    String imprimir(Nodo raiz){
        Nodo recorre;//se guarda un nodo llamado recorrer
        recorre=raiz;//recorrer es igual a la raiz
        String cad=" ";//se declara una cadenan auxiliar
        if(recorre==null) {
            System.out.println("La lista esta vacia");//si la lista recibida esta vacia se avisa al usuario
        } else{
            while(recorre.sig!=null){//mientras hallan datos
                cad=cad+recorre.valor+" -> ";//se recorre la cadena
                //JOptionPane.showMessageDialog(null, cad);
                recorre=recorre.sig;
            }
        cad=cad+recorre.valor+" null";//se devuelve null como ultimo elemento
        return cad;
       }
       return cad;
      }
        String imprimir(Nodo raiz, Nodo raiz1){//fucion para la union
        Nodo recorre;
        recorre=raiz;
        String cad=" ";
        if(recorre==null) {
            System.out.println("La lista" + 1 + " esta vacia");
        } else{
            while(recorre.sig!=null){
                cad=cad+recorre.valor+" -> ";
                
                recorre=recorre.sig;
            }
            recorre = raiz1;//una vez recorrida la primera lista
            if(recorre==null) {
                System.out.println("La lista " + 2 + " esta vacia");
            }else{
                 while(recorre.sig!=null){
                    cad=cad+recorre.valor+" -> ";
                    
                    recorre=recorre.sig;//se recorre la seguna
                    }
                }
       
        cad=cad+recorre.valor+" null";//se imprime null como ultimo elemento
        return cad;
       }
 
       return cad;
      }
    
    public static void main(String[] args){

        Conjuntos start = new Conjuntos();
        System.out.println("Inserte la cantidad de conjuntos");
        n = reader.nextInt();//se guarda la cantidad de conjuntos
 
        miVector = new Lista[n];//se dimensiona un vector tipo lista que almacena n raices de listas conjuntos
        
       for( i = 0; i< n; i++){//se repite n veces
           miVector[i] = new Lista();//se inicializa el vector
           miVector[i].raiz = start.cargarDato(miVector[i].raiz );//se empieza a cargar datos    
           x = 0;
       }
        
        for( i = 0; i< n; i++){//se imprime para verificar que se ingresaron bien los datos
            int j = i + 1;
           System.out.println("Los elementos de la lista " + j + " son: " + start.imprimir(miVector[i].raiz));
        }
        int flag = 0;
        int aux,aux1;
        String valor;
                
        while( flag != 1){
            System.out.println("1) Pertenecia\n2) Eliminar dato\n3)Agregar dato\n4)Unir dos conjuntos");//menu
            int opcion = reader.nextInt();
            
            switch (opcion) {
                case 1:
                    System.out.println("Ingrese el numero de la lista en el cual buscar");
                    aux = reader.nextInt();
                    aux = aux - 1;
                    System.out.println("Ingrese el valor del dato a buscar");
                    valor = reader.next();
                    start.pertenencia(miVector[aux].raiz,valor,aux);
                    break;
                    
                case 2:
                    System.out.println("Ingrese el numero de la lista en el cual elminar el dato");
                    aux = reader.nextInt();
                    aux = aux - 1;
                    System.out.println("Ingrese el valor del dato a borrar");
                    valor = reader.next();
                    start.borrar(miVector[aux].raiz,valor);//se procede a elminar el valor
                    int j = aux + 1;//variable para imprimir para el user
                    //se muestra la nueva lista con el elemento borrado
                    System.out.println("Los elementos del conjunto " + j + " son: " + start.imprimir(miVector[aux].raiz));
                    break;
                    
                case 3:
                    System.out.println("En cual conjunto desea anhadir mas datos?");
                    aux = reader.nextInt();
                     miVector[aux].raiz = start.cargarDato(miVector[aux].raiz );    
                    break;
                
                case 4:
                    System.out.println("Cuales son los conjuntos que queres unir");
                    aux = reader.nextInt();
                    aux1 = reader.nextInt();
                    //se unen los dos conjuntos
                    System.out.println("Los elementos de la union de los conjuntos: "  +  aux + " y " + aux1 + " son:" + start.imprimir(miVector[aux-1].raiz, miVector[aux1-1].raiz));
                    
                    break;
                    
                default:
                    break;
                
                    
            }
    
        }
    }

 }
