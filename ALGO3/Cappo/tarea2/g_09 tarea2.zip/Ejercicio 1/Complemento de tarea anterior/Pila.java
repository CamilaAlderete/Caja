/*
    Eric Ruiz Diaz
    Ruben Izembrandt
    01/03/2018
    Ejercicio 3.a
*/

public interface Pila{
    public void apilar(int n);
    public int desapilar();
    public int tope();
    public boolean esVacia();
    public int size();
    
}


