/*
    Eric Ruiz Diaz
    Ruben Izembrandt
    01/03/2018
    Ejercicio 3.a
*/
import java.util.ArrayList;



public class PilaArreglo implements Pila{
    
    private ArrayList lista;

    public PilaArreglo() {
        this.lista = new ArrayList();
    }
    
    
   
    
    public void apilar(int n){
        lista.add(n);
    }

    public int tope() {
      return lista.size();
    }
    
    public int desapilar() {
        int dev=(int) lista.get(tope()-1);
        lista.remove(tope()-1);
        return dev;
    }
   
    public boolean esVacia() {
        return lista.isEmpty();
    }

    
    public int size() {
      return lista.size();
    }

   
}
