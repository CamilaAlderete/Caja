/*
    Eric Ruiz Diaz
    Ruben Izembrandt
    01/03/2018
    Ejercicio 3.a
*/
import java.util.logging.Level;
import java.util.logging.Logger;


class Nodo { 
      public int dato;
      public  Nodo next;

	 
      Nodo ( int d ) {
         dato = d;
         next = null;        
      }

      public void setNext ( Nodo n ) throws Exception {
         if ( n != this ) 
            next = n;
         else {
			
            System.out.println ("No puede apuntar a si mismo");
			System.exit(1);
		 }	
      }
      
}


class IteradorLista {
     private Nodo actual ; 
     
     IteradorLista (PilaLista list ) { //
         actual = list.cabeza;
     }

	 
	 int desapilar () throws Exception {
	 	 if ( ! esVacia() ) {
		     
			 System.out.println("Pila vacia");
			 System.exit(1);
		 }	 
         int d  = actual.dato;
         actual = actual.next;
         return d;   
     }

	 
    public boolean esVacia () {
        if ( actual != null ) 
            return true;
        else
            return false;         
     }
}


public class PilaLista implements Pila{
   Nodo cabeza; 
   
   
   PilaLista ( ) {
       cabeza = null;
   }

   
   
   public void apilar ( int n )  { 
       try {
           Nodo tmp  = cabeza ;
           cabeza    = new Nodo(n); 
           cabeza.setNext(tmp);
       } catch (Exception ex) {
           Logger.getLogger(PilaLista.class.getName()).log(Level.SEVERE, null, ex);
           System.out.println("Pila llena");
       }
   }   

   
   
   
   IteradorLista getIterador () {
      return new IteradorLista (this);
   }
   
   
   
   public static void main ( String [] args ) throws Exception { 
      PilaLista l = new PilaLista();

      l.apilar (10);
      l.apilar (20);
      l.apilar (30);
      l.apilar (50);
	  
      IteradorLista il = l.getIterador();
 
      for ( ; il.esVacia(); ) {
         int d = il.desapilar();
         System.out.println(d);
      } 
      
	  il.desapilar(); 
   }

    

    
    public int desapilar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    public int tope() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    public int size() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public boolean esVacia() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}