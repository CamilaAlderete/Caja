/*
    Eric Ruiz Diaz
    Ruben Izembrandt
    01/03/2018
    Ejercicio 3.a
*/

import java.util.Scanner; 

public class Principal {
    static PilaArreglo p=new PilaArreglo();
    
    public static void main(String [] args ){
        
        Scanner sc=new Scanner(System.in);
        
        int cant_datos;
        int dato;
        System.out.print("Ingrese cuantos numeros ingresara en la pila \n");
        
        cant_datos=sc.nextInt();
        System.out.print("Ingrese los numeros \n");
        for(int i=0;i<cant_datos;i++){
                  
            dato=sc.nextInt();
            
            p.apilar(dato);
        }
        
        for(;!p.esVacia();){
            System.out.println("El objeto apilado es " + p.desapilar());
        }
        System.exit(1);
    }
}
