
/*
    Eric Ruiz Diaz
    Ruben Izembrandt
    01/03/2018
    Ejercicio 3.a
*/


public interface Pila{
    public void apilar(char n);
    public char desapilar();
    public String tope();
    public boolean esVacia();
    public int size();
    
}


