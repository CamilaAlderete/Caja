



import java.util.ArrayList;

/*
    Eric Ruiz Diaz
    Ruben Izembrandt
    01/03/2018
    Ejercicio 3.a
*/

public class PilaArreglo implements Pila{
    
    public ArrayList lista;

    public PilaArreglo() {
        this.lista = new ArrayList();
    }
    
    
   
    
    public void apilar(char n){
        lista.add(n);
    }

    public String tope() {
      
      return (String) lista.get(lista.size());
    }
    
    public char desapilar() {
        char dev=(char) lista.get(size()-1);
        lista.remove(size()-1);
        return dev;
    }
   
    public boolean esVacia() {
        return lista.isEmpty();
    }

    
    public int size() {
      return lista.size();
    }

   
}
