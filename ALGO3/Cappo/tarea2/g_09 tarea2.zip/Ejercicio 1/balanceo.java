




/*
    Eric Ruiz Diaz
    Ruben Izembrandt
    01/03/2018
    Ejercicio 3.a
	
	Este ejercicio fue hecho con ayuda y guia de la pagina de la Universidad Nacional Autonoma de Mexico
*/
public class balanceo extends PilaArreglo{
 
    PilaArreglo lista=new PilaArreglo();
    
    public static void main(String [] args ){  
      if (args.length != 1) {
	  System.out.println("Ingrese correctamente los datos");
      } else {
	  new balanceo(args[0]);
      }
      
  }
        
     private boolean test (char c) {
      if (lista.esVacia()) {
	  System.out.println("La expresion no esta balanceada"); 
	  return false;
      } else {
	  Character s = (Character) lista.desapilar();  
	  if (c != s.charValue()) {
	      System.out.println("La expresin no esta balanceada"); 
	      return false; 
	  }
      }
        return true;
  } 
  public balanceo (String linea) {
      for (int i = 0; i < linea.length(); i++) {
          switch (linea.charAt(i)) {
              case '(':
                  lista.apilar(')');
                  break;
              case '{':
                  lista.apilar('}');
                  break;
              case '[':
                  lista.apilar(']');
                  break;
              case ')':
                  if(test(')')==false){
                      System.out.println(linea+"\t");
                      for(int j=1;j<=i;j++)System.out.println(" ");
                      System.exit(0);
                  };
                  break;
              case '}':
                  if(test('}')==false){
                  System.out.println(linea+"\t");
                      for(int j=1;j<=i;j++)System.out.println(" ");
                      System.exit(0);
                  }
                  break;
              case ']':
                  if(test(']')==false){
                  System.out.println(linea+"\t");
                      for(int j=1;j<=i;j++)System.out.println(" ");
                      System.exit(0);
                  }
                  break;
              default:
                  break;
          }
      }

      if (lista.esVacia())
	  System.out.println("Parentesis balanceados");
      else 
	  System.out.println("Parentesis NO balanceados");	  
  }
   
}
    
