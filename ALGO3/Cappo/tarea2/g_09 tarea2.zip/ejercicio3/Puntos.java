//01/3/2018
//Este trabajo fue hecho por Ruben Izembrandt y Eric Ruiz Diaz
//Ejercicio 2

import java.util.*;

public class Puntos {
    
     public double x1,y1;
  class Coordenadas//tad para la funcion a implementar
  {
    double x;
    double y;
 
    Coordenadas(double x, double y)//funcion para inicializar coordenadas
    {
      this.x = x;
      this.y = y;
    }

     public String toString()
    {  return "(" + x +" , " + y + ")";  }//devuelve una cadena para imprimir las coordendas
  }
 
  final class Par//tad para almacenar un conjunto de numeros
  {
    public Coordenadas punto1 = null;
    public Coordenadas punto2 = null;
    public double distancia = 0.0;
 
     Par()
    {  }
 
    Par (Coordenadas punto1, Coordenadas punto2)//para inicializar los datos
    {
      this.punto1 = punto1;
      this.punto2 = punto2;
      calcDistancia();
    }
 
    public void update(Coordenadas punto1, Coordenadas punto2, double distancia)//funcion para acualizar los datos
    {
      this.punto1 = punto1;
      this.punto2 = punto2;
      this.distancia = distancia;
    }
 
    public void calcDistancia()//funcion para guardar la distancia 
    {  this.distancia = distancia(punto1, punto2);  }
 
    public String toString()//funcion para imprimir el valor final
    {  return punto1 + " y " + punto2 + "\nSu distancia es: " + distancia;  }
  }
 

     
    void cargarPuntos(List<Coordenadas> puntos){//funcion para cargar puntos en una array tipo Lista
    
        Scanner reader = new Scanner(System.in);
        System.out.println("Ingrese la cantidad de puntos a procesar");
        int cantidad = reader.nextInt();
        
        for (int i = 0; i < cantidad; i++){//se lee la cantidad de puntos ingresados
         
          
           System.out.println("Inserta la coordenada en 'X' del punto " + i); 
           x1 =  reader.nextDouble();//se lee el valor de x
           
           System.out.println("Inserta la coordenada en 'Y' del punto " + i); 
           y1 = reader.nextDouble();//se lee el valor de y
           puntos.add(new Coordenadas(x1, y1));//se agregan a su lugar correspondiente en el vector
          
        }
    }
    

    
   double distancia(Coordenadas p1, Coordenadas p2){//funcion para calcular la distancia
 
     
    double xdist = p2.x - p1.x;//se cacula la distancia de los ejes x
    double ydist = p2.y - p1.y;//lo mismo con los ejes y
    
    return Math.hypot(xdist, ydist);//se calcula la distancia entre el par de puntos con la ayuda del principio de hipotenusa
 
  }
  
  
   Par fuerzaBruta(List<? extends Coordenadas> puntos){//se calcula la menor distacia entre n puntos siendo estos menores o iguales a 
    
    int numPoints = puntos.size();//se obtiene con la funcion size la cantidad de puntos
    if (numPoints < 2){//si es menor a 2
      return null;//retorna null ya que no tiene otro punto para calcular su distancia
    }
    
    Par par = new Par(puntos.get(0), puntos.get(1));
    if (numPoints > 2){//si es mayor a 2
            
      for (int i = 0; i < numPoints - 1; i++){//ciclo for
        Coordenadas punto1 = puntos.get(i);//se almacena en punto1 el valor de puntos[i]
        
        for (int j = i + 1; j < numPoints; j++){//ciclo for nested
          Coordenadas punto2 = puntos.get(j);//se almacena el valor del punto[j]
          double distancia = distancia(punto1, punto2);
          if (distancia < par.distancia){//si la distancia nueva es menor a la distancia menor, la distancia menor es igual a la distancia nueva
            par.update(punto1, punto2, distancia);//se actualizan los valores
          }
        }
      }
    }
    return par;//se retorna el par mas cercano
  }
   
   
    void ordenX(List<? extends Coordenadas> puntos){//se ordenan por x los datos
 
    Collections.sort(puntos, new Comparator<Coordenadas>() {//se usa el mergesort integrado
        
      
        public int compare(Coordenadas punto1, Coordenadas punto2){//se pasa los valores a corroborar
          if (punto1.x < punto2.x){//se pasan las condiciones
            return -1;
          }
          if (punto1.x > punto2.x){//condicion 2
            return 1;
          }
          return 0;//son iguales retorna 0
        }
      }
    );
  }
 
    void ordenY(List<? extends Coordenadas> puntos){//se ordenan por y lso datos
 
    Collections.sort(puntos, new Comparator<Coordenadas>() {

        public int compare(Coordenadas punto1, Coordenadas punto2){
          if (punto1.y < punto2.y){//condicion 1
            return -1;
          }
          if (punto1.y > punto2.y){//condicion 2
            return 1;
          }
          return 0;//si son iguales se retorna 0
        }
      }
    );
  }
    
  
    Par divideVenceras(List<? extends Coordenadas> points){//funcion recursiva para separar las listas en sublistas
        List<Coordenadas> puntosOrdenX = new ArrayList<>(points);//nueva lista
        ordenX(puntosOrdenX);//se ordena la nueva lista
        List<Coordenadas> puntosOrdenY = new ArrayList<>(points);
        ordenY(puntosOrdenY);//divide
        return divideVenceras(puntosOrdenX, puntosOrdenY);//venceras
    } 
  
  
  
    Par divideVenceras(List<? extends Coordenadas> puntosOrdenX, List<? extends Coordenadas> puntosOrdenY){//funcion recursiva para hallar el par mas cercano
    int numPuntos = puntosOrdenX.size();
    if (numPuntos <= 3){//si son menores a tres los puntos se llama directo a la fuerza bruta para ahorrar tiempo de ejecucion
      return fuerzaBruta(puntosOrdenY);
    }
 
    int dividirIndice = numPuntos >>> 1;//divide
    List<? extends Coordenadas> izquierda = puntosOrdenX.subList(0, dividirIndice);
    List<? extends Coordenadas> derecha = puntosOrdenY.subList(dividirIndice, numPuntos);
 
    List<Coordenadas> tempList = new ArrayList<>(izquierda);//se calcula por al izquierda
    ordenY(tempList);
    Par parMasCercano = divideVenceras(derecha, tempList);//por la derecha
 
    tempList.clear();
    tempList.addAll(derecha);
    ordenY(tempList);
    Par derechaMasCercano = divideVenceras(derecha, tempList);
 
    if (derechaMasCercano.distancia < parMasCercano.distancia) {
        parMasCercano = derechaMasCercano;//se guarda el mas cercano
    }
 
    tempList.clear();
    double distanciaMenor =parMasCercano.distancia;
    double centerX = derecha.get(0).x;
    for (Coordenadas point : puntosOrdenY) {
        if (Math.abs(centerX - point.x) < distanciaMenor) {
            tempList.add(point);
        }
    }
 
    for (int i = 0; i < tempList.size() - 1; i++)//se calcula la distancia con un for
    {
      Coordenadas point1 = tempList.get(i);
      for (int j = i + 1; j < tempList.size(); j++)//nested for
      {
        Coordenadas point2 = tempList.get(j);
        if ((point2.y - point1.y) >= distanciaMenor) {
            break;
        }
        double distance = distancia(point1, point2);
        if (distance < parMasCercano.distancia)
        {
          parMasCercano.update(point1, point2, distance);
          distanciaMenor = distance;//se guarda la distancia menor
        }
      }
    }
    return parMasCercano;//se retorna el par mas cercano
  }
 
      public static void main(String[] args){
    
        Puntos start = new Puntos();
        //Coordenadas[] vecPuntos = 
        List<Coordenadas> puntos = new ArrayList<>();
        start.cargarPuntos(puntos);

        Par pardivideVenceras = start.divideVenceras(puntos);
        System.out.println("El par mas cercano es: "+pardivideVenceras);
   
        
    }
}


 
