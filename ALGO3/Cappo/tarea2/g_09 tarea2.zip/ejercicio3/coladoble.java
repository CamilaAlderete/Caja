



/*
    Eric Ruiz Diaz
    Ruben Izembrandt
    01/03/2018
    Ejercicio 3.a
*/
class nodo{
        public int valor;
        public nodo sig;
        public nodo ult;
        public nodo prim;
    

    nodo(int d){
        valor=d;
        sig=null;
        ult=null;
        prim=null;
        
    }
    public void setNext ( nodo n ) throws Exception {
         if ( n != this ) 
            sig = n;
         else {			
            System.out.println ("No puede apuntar a si mismo");
			System.exit(1);
		 }	
      }
}

class IteradorCola {
     private nodo actual ; 
     
     IteradorCola (coladoble list ) { 
         actual = list.cabeza;
     }

	  
	 int next () throws Exception {
	 	 if ( ! hasNext() ) {
		     
			 System.out.println("Fin de cola doble");
			 System.exit(1);
		 }	 
         int d  = actual.valor;
         actual = actual.sig;
         return d;   
         }
        boolean hasNext () {
            if ( actual != null ) 
                return true;
            else
                return false;         
        }
         }

public class coladoble {
    
    nodo cabeza;
    
    coladoble (){
        cabeza=null;
    }
    public void push(int c) throws Exception{
       nodo nuevo = null;
       nuevo.valor=c;
       nuevo.prim=null;
       cabeza.prim=nuevo;
    }
    
    public int pop(){    
        return cabeza.prim.valor;
    }
    
    public void inyectar(int c){
       nodo nuevo = null;
       nuevo.valor=c;
       nuevo.prim=null;
       cabeza.ult=nuevo;
    }
    
    public int eyectar(){
        return cabeza.prim.valor;  
    }
    
    public int size(){
       nodo test = null;
       int j=0; 
       while(test.ult==null){
            test=cabeza.ult;
            j++;
        }
        return j;
    
    }
}
