/*
    G 09
    Ruben Izembrandt
    Eric Ruiz Diaz

*/
typedef struct tipo_nodo{
    int tipo_dato;//para distinguir si es una lista, cadena o entero el tipo de dato que contiene el nodo
    void *vptr;//puntero void a vacio
    struct tipo_nodo* sig;//un puntero al siguiente
}Nodo;

void menu();//prototipado
Nodo* crear_nodo(Nodo* nodo_ant);//prototipado
void cargar_datos(Nodo * cabeza);//prototipado
Nodo* ptr_cabeza = NULL;
