#include<stdio.h>
#include<stdlib.h>
#include <string.h>
#include "g09_tarea_1.2_a3.h"

/*
    G 09
    Ruben Izembrandt
    Eric Ruiz Diaz
*/

void cargar_datos(Nodo * cabeza){  //recibe un nodo cabecera ya que se llama a esta funcion cada vez que empieza una lista
    int option;
    Nodo* nodo_ant;//se crea un nodo anterior auxiliar
    if (ptr_cabeza != NULL){//si no es el primer elemento de la lista principal
        nodo_ant = cabeza;//usar como pointer a cabecera de la sublista
    }

    while(option!=4){//mientras no se termine la lista que se siga cargando datos
        menu();
        Nodo* nodo;//se crea un nodo
        scanf("%d",&option);//se lee el valor del dato a ingresar
        switch(option){
            case 1:
                printf("Ingrese un entero\n");
                int * ptrInt = malloc(sizeof(int));//se crea un int dinamico para guardar en la lista
                scanf("%d",ptrInt);//se guarda en la memoria dinamica el valaor del nodo
                nodo = crear_nodo(nodo_ant);//se linkea el nodo con el nodo anterior
                nodo->vptr = ptrInt;//se apunta a la memoria dinamica con el dato del nodo
                nodo->tipo_dato = 1;
                break;
            case 2:
                printf("Ingrese una cadena\n");
                char * ptrChar = malloc(sizeof(char[20]));//se crea una variable dinamica char
                scanf("%s",ptrChar);//se almacena en esa variable los datos del nodo
                nodo = crear_nodo(nodo_ant);//se linkea con el nodo anterior
                nodo->vptr = ptrChar;//el nodo apunto a la memoria dinamica donde esta la cadena
                nodo->tipo_dato = 2;
                break;
            case 3:
                printf("Ha creado nueva lista\n");
                nodo = crear_nodo(nodo_ant);//se crea un nuevo nodo
                Nodo * aux;//se crea un nodo auxiliar
                nodo->vptr = aux;//se apunta al nodo auxiliar que servira como raiz oara la sublista
                cargar_datos(aux);//se vuelve a cargar datos y aux seria la cabecera de la nueva lista
                nodo->tipo_dato = 3;
                break;
            case 4:
                printf("Ha terminado la lista\n");
                nodo = crear_nodo(nodo_ant);//se linkea con el nodo anterior
                nodo->tipo_dato = 4;
                break;
            default:
                break;
        }
        nodo_ant = nodo;//se mueve uno la lista enlazada
    }
}
void menu(){
    system("cls");
    printf("1)Ingresar entero\n2)Ingresar cadena\n3)Ingresar lista\n4)Dejar de Cargar\n");
}

Nodo* crear_nodo(Nodo* nodo_ant){
    Nodo* nuevo = (Nodo *)malloc(sizeof(Nodo));// se crea una nueva lista con el tamano de nodo
    if(ptr_cabeza == NULL){//si el putero es null
        nuevo->sig=NULL;//el siguiente se nullea por si no hay mas elementos
        ptr_cabeza = nuevo;//la cabeza es igual al nodo
    }else{
        nuevo->sig = NULL;//el siguiente se nullea por si no hay mas elementos/
        nodo_ant->sig = nuevo;//el anterior se conecta al actual
        }
    return nuevo;//se retorna el nodo
}
void imprimir_lista(Nodo* nodo){
    if(ptr_cabeza == nodo){//si empieza la lista
        printf("( ");//imprimir parentesis abierto
    }
    else if(nodo->tipo_dato < 3){//si el dato es numerico o cadena
        printf(", ");//se imprime coma para espaciar los datos
    }
    switch(nodo->tipo_dato){//se hace un switch case del tipo de dato

    case 1:
        printf("%d",*(int *)nodo->vptr);//se castea el void puntero para poder desrreferenciar la plantilla del void puntero int
        if((nodo->sig) != (NULL)){//si el siguiente es distinto de null
            imprimir_lista(nodo->sig);//se imprime el siguiente nodo
        break;
        }
    case 2:
        printf("%s",(char *)nodo->vptr);////se castea el void puntero para poder desrreferenciar la plantilla del void puntero string
        if(nodo->sig!=NULL){
            imprimir_lista(nodo->sig);
        }
        break;
    case 3:
        printf("( ");//se imprime una llave para abrir
        imprimir_lista(nodo->vptr) ;//se imprime la sublista desde el nodo que lo contiene
        break;
    case 4:
        printf(" )");//se imprime una llave para cerrar
        break;
    }
}
int main(){
    menu();//se crea un puntero cabeza
    ptr_cabeza = NULL;
    cargar_datos(ptr_cabeza);//se cargan datos
    Nodo * NODO = ptr_cabeza;
    system("pause");
    imprimir_lista(NODO);//se imprimen los datos
    return 0;
}
