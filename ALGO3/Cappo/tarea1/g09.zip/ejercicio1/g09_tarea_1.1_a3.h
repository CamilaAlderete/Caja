/*
    Ruben Izembrandt
    Eric Ruiz Diaz
*/
 typedef struct tipo_nodo {
        char dato[20];
        struct  tipo_nodo *siguiente;
}Nodo;

 Nodo *primero, *ultimo;//punteros al ultimo y primer elemeto
 int pertenencia(char* dato2);
 void mostrar_menu() ;
 void anadir_elemento();
