#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "g09_tarea_1.1_a3.h"

/*
    Ruben Izembrandt
    Eric Ruiz Diaz
*/
 void mostrar_menu() {//menu
      printf("\n\nMen�:\n=====\n\n");
      printf("1.- A�adir elementos\n");
      printf("2.- Pertenencia\n");
      printf("3.- Mostrar lista\n");
      printf("4.- Salir\n\n");
      printf("Escoge una opci�n: ");fflush(stdout);
 }

 void anadir_elemento() {
        Nodo* nuevo;
        int bandera = 0;//bandera para que no se agregue un elemento repetido al conjunto
        nuevo = (Nodo *)malloc(sizeof(Nodo));//nuevo elemento cadena
        if (nuevo==NULL){
            printf( "No hay memoria disponible!\n");//se lleno la memoria
        }
        printf("\nInserte Cadena:\n");
        gets(nuevo->dato);//leer el dato

        nuevo->siguiente = NULL;//se nullea el siguiente por si ya no se agreguen datos

        if (primero==NULL) {//no hay aun elementos
            printf( "Primer elemento\n");
            primero = nuevo;//el puntero primero apunta a el nuevo nodo
            ultimo = nuevo;//el puntero ultimo apunta al nuevo nodo
         }
        else {
            Nodo* ptr = primero;//se guarda el valor del primer nodo
            while(ptr != NULL){//se verifica toda la lista
                if(strcmp(nuevo->dato,ptr->dato)==0){//si se repite la cadena
                    bandera = 1;//la bandera indica que ya no se puede agregar este elemento
                    free(nuevo);
                    puts("Este elemento ya existe");
                }
            }
            if (bandera = 0){//si no se repite
                ultimo->siguiente = nuevo;//el siguiente del ultimo apunta al nuevo nodo
                ultimo = nuevo;//el ultimo apunta al nuevo nodo
            }
        }
    }

 int pertenencia(char* dato2){
    Nodo* ptr;//se declara un ptr auxiliar

    ptr = primero;//se apunta al primero
    int flag = 0;//se usa una badera para ver si la variable pertenece al conjunto
    do{
        if((strcmp(ptr->dato, dato2)) == 0){//si el elemento se repite dentro del conjunto
          flag = 1;//la bandera indica que existe pertenencia
        }

    }while(ptr != NULL);//hasta el ultimo nodo se repite este procedimienti
    return flag;//se devuelve la bandera
}
 void mostrar_lista() {
      Nodo *auxiliar; //nodo auxiliar
      int i = 0;//se declara un contador
      auxiliar = primero;//el nodo auxiliar toma el valor del primer nodo o cabecera
      printf("\nLista completa:\n");
      while (auxiliar!=NULL) {//si el ptr auxiliar del nodo no llego al final de la lista
            printf("'%s', ",auxiliar->dato);//se imprime el dato;
            i++;//se aumenta el contador
      }
      if (i==0) printf( "\nLa lista est� vac�a!!\n" );//si el contador esta en 0, la lista esta vacia!
 }

 int main() {
     char opcion;

     primero = (Nodo *) NULL;//se declara el puntero a primer nodo
     ultimo = (Nodo *) NULL;//se declara el puntero al ultimo nodo
     do {
         mostrar_menu();//se llama a mostrar menu
         opcion = getchar();//se lee la variable opcion
             switch ( opcion ) {
                case '1': anadir_elemento();
                       break;
                case '2':
                        printf("Inserte una cadena para comparar\n");
                        char* cad;//se declara una cadena secundaria
                        scanf("%s",&cad);//se lee el dato
                        pertenencia(cad);//se llama a la funcion pertenenia y se compara si el elemento pertenece al conjunto
                        break;
                case '3': mostrar_lista(primero);
                        break;
                case '4': exit( 1 );
                default: printf( "Opci�n no v�lida\n" );
                         break;
             }
     } while (opcion!='4');
 }
