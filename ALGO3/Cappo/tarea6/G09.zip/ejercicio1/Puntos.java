//import java.util.ArrayList;
/*
	G09
	Eric Ruiz Diaz
	Ruben Izembrandt
*/
public class Puntos implements Comparable<Puntos>{
	public int x;
	public int y;
	public boolean mayor;
	//public static ArrayList<puntos>lista;
	
	/*puntos(int px,int py){
		this.x=px;
		this.y=py;
		this.lista=new ArrayList<puntos>(lista);
	}
	public void add_points(int px,int py){
		puntos test=new puntos(px,py)
		this.lista.add(lista);
		
	}*/
	
	Puntos(int px,int py){
		this.x=px;
		this.y=py;
		this.mayor=false;
	}

	public int get_x(){
		return this.x;
	}

	public int get_y(){
		return this.y;
	}
	public boolean get_mayor(){
		return this.mayor;
	}

	@Override
	public int compareTo(final Puntos punto1){
		
		//System.out.println("Las y son:"+punto1.get_y()+" " +this.y);
		//System.out.println("Las x son: "+punto1.get_x()+" " +this.x);
		
		if(punto1.get_y()>this.y){
			//System.out.println("Primer if");
			punto1.mayor=true;
			if(punto1.get_x()>this.x){
			//	System.out.println("Segundo if");
				punto1.mayor=true;
				return 1;	
			}else{
			//	System.out.println("Primer else");
				return -1;
			}
			
		}else{
		//	System.out.println("Segundo else");
			if(punto1.get_y()<this.y){
		//		System.out.println("Tercer if");
				punto1.mayor=false;
				return -1;
			}else{
				if(punto1.get_x()>this.x){
					punto1.mayor=true;
		//			System.out.println("Cuarto if");
					return -1;
				}
			}
		}
	return 0;
	}
}