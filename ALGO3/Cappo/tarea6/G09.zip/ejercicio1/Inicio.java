import java.util.Scanner;
/*
	G09
	Eric Ruiz Diaz
	Ruben Izembrandt
*/
public class Inicio{

	public static <T extends Comparable<T>> void qsort (T[] arr, int a, int b) {
        if (a < b) {
            int i = a, j = b;
            T x = arr[(i + j) / 2];

            do {
                while (arr[i].compareTo(x) < 0) i++;
                while (x.compareTo(arr[j]) < 0) j--;

                if ( i <= j) {
                    T tmp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = tmp;
                    i++;
                    j--;
                }

            } while (i <= j);

            qsort(arr, a, j);
            qsort(arr, i, b);
        }
    }




public static void main(String args[]){
		Scanner leer=new Scanner(System.in);
		Puntos [] lista =new Puntos[5];
		System.out.println("Ingrese/Pegue los puntos:");
		for(int i=0; i<5 ;i++){
			lista[i] = new Puntos(leer.nextInt(),leer.nextInt());
		}

		GenericQuicksortComparable.<Puntos>qsort(lista, 0, lista.length-1);
       for(int i=0; i<5; i++){
       		//System.out.println("uh");
       		if(lista[i].get_mayor()==true){
       			System.out.printf("Un punto maximo es: (%d,%d)\n",lista[i].get_x(),lista[i].get_y());
       		}
       }
	}
}