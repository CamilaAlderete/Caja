/*
    G09
    Eric Ruiz Diaz
    Ruben Izembrandt
    Bibliografia: Diapositivas de clase + geeksforgeeks.org/radix-sort
*/
import java.io.*;
import java.util.*;
 
class Radix {
    //metodo para obtener el maximo valor del arreglo
    static int getMax(int arr[], int n){
        int mx = arr[0];
        for (int i = 1; i < n; i++){
            if (arr[i] > mx)
                mx = arr[i];
        }
        return mx;
    }
 
    //ordenamiento countsort
    static void countSort(int arr[], int n, int exp){
        int salida[] = new int[n]; 
        int i;
        int contador[] = new int[10];
        Arrays.fill(contador,0);
        for (i = 0; i < n; i++){
            contador[ (arr[i]/exp)%10 ]++;
        }
        for (i = 1; i < 10; i++){
            contador[i] += contador[i - 1];
        }
        for (i = n - 1; i >= 0; i--){
            salida[contador[ (arr[i]/exp)%10 ] - 1] = arr[i];
            contador[ (arr[i]/exp)%10 ]--;
        }
        for (i = 0; i < n; i++){
            arr[i] = salida[i];
        }
    }
 
    //llamada al countsort
    static void radixsort(int arr[], int n){
        int m = getMax(arr, n);
        for (int exp = 1; m/exp > 0; exp *= 10){
            countSort(arr, n, exp);
        }
    }
 
    //imprimir el vector
    static void print(int arr[], int n){
        for (int i=0; i<n; i++){
            System.out.print(arr[i]+" ");
        }
    }
 
 
 /*
    public static void main (String[] args){
        int arr[] = {321,543,36,4523,5,54,,65865,643,6,345,5235,324};
        int n = arr.length;
        radixsort(arr, n);
        print(arr, n);
    }*/
}