/*
	Integrantes:
	G16 - Luis Pereira y Eric Ruiz Diaz

	Con la participacion y creditos respectivos a G03 Camila Alderete

*/

/*
  Algoritmos y ED III
*/

// interface para tipos de datos...

public interface Cmp{
 
   public int cmp( Cmp b );	// Metodo de comparacion...
   
   public void imprimir();	// Metodo de impresion...
}