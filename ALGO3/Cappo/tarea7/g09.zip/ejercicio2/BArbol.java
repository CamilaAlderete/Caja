/*
 * BArbol.java
 * 
 * ALGORITMOS Y ESTRUCTURAS DE DATOS III
 * 
 * Implementa un B-Arbol de elementos polimorficos.
 * El algoritmo utilizado es el descripto en el libro
 * "Algoritmos y Estructuras de datos" de N. Wirth (1987).
 * 
 * Si bien la estructura general original se conservo, se
 * introdujeron cambios en esta implementacion Java (dado
 * no hay parametros por referencia). El codigo resultante
 * es (eso se espera) mas legible que el original.
 *
 * 
 */

/**
 * Implementa un B-Arbol.
 *
 * Cada pagina del arbol es del tipo PaginaBArbol
 * (ver fuente correspondiente para detalles de la estructura utilizada).
 *
 * OBSERVACION: Se podria mejorar la interrelacion con PaginaBArbol, no
 *    accediendo directamente a ningun dato de PaginaBArbol. Esto queda
 *    como ejercicio (requerira agregar metodos en PaginaBArbol).
 */
 
import java.util.concurrent.ThreadLocalRandom;
import java.util.Scanner;
import java.util.ArrayList;
public class BArbol <T extends Comparable<T>>
{
   /*
    * Por defecto, almacenamos 10 items en cada pagina. (Este numero
    * es completamente arbitrario y su eleccion no tiene ningun 
    * proposito especifico).
    */

   private int orden;

   public PaginaBArbol raiz = null;

   /*
    * item_a_subir_dato:
    *   Es una referencia al dato que debe "flotar
    *   hacia arriba en el arbol (por ejemplo cuando se esta agregando
    *   un elemento).
    *
    */

  private T item_a_subir_dato;
   /*
    * item_a_subir_ptr_may:
    *   Es una referencia a la pagina inferior (o "derecha") que contiene
    *   los elementos mayores al dato referenciado por "item_a_subir_dato".
    *   
    *   Esta variable es complemento (trabaja con) item_a_subir_dato
    *   y ayudan a implementar el parametro "v" utilizado en el codigo
    *   de Wirth (donde se recibe por referencia).
    */
   private PaginaBArbol item_a_subir_ptr_may;

   public BArbol (int orden)
   {
      item_a_subir_dato = null;
      item_a_subir_ptr_may = null;

      this.orden = orden;
   }
   public PaginaBArbol obtenerRaiz(){return raiz;}
   public void agregar(T d)
   {
      item_a_subir_dato = null;
      item_a_subir_ptr_may = null;

      priv_agregar (raiz, d);

      /*
       * Si un item "floto" hacia la raiz y no se resolvio su
       * insercion antes, quiere decir que la raiz se partio en
       * dos, por lo que debemos crear una nueva raiz.
       *
       * Tambien se ejecuta esta parte cuando se agrega el primer
       * elemento del arbol, por lo que se crea la pagina raiz.
       */

      if ( item_a_subir_dato != null )
      {
         PaginaBArbol copia_raiz = raiz;
    
         raiz = new PaginaBArbol (this.orden);
         raiz.m = 1;
         raiz.may.set(0, copia_raiz);
         raiz.asignarItem (1, item_a_subir_dato, item_a_subir_ptr_may);
      }
   }

   /*
    * item_a_subir() se utiliza unicamente para escribir menos
    * y hacer mas legible el codigo.
    */
   private void item_a_subir (PaginaBArbol pg, int pos)
   {
      item_a_subir_dato = pg.dato.get(pos);
      item_a_subir_ptr_may = pg.ptrMayor (pos);
   }


   /*
    * Agrega un dato al arbol.
    *
    * Si un item (es decir, un dato + su puntero ¨derecho¨ deben subir,
    * las variables item_a_subir_dato e item_a_subir_ptr_may contienen
    * las referencias correspondientes (es decir, apuntan al item).
    */
    void proct_agregar (PaginaBArbol pg, T d)
   {
   		priv_agregar(pg, d);
   }
   
   
   private void priv_agregar (PaginaBArbol pg, T d)
   {
      int R;

      T u_dato;
      PaginaBArbol u_ptr_may;

      /*
       * Si pg == null, significa que el dato no se encuentra
       * en el arbol, por lo que indicamos que un nuevo item
       * (formado por el dato + un puntero derecho null) debe
       * ¨flotar¨ hacia la raiz.
       */

      if ( pg == null )
      {
         item_a_subir_dato = d;
         item_a_subir_ptr_may  = null;
         return;
      }

      R = pg.buscar (d);

      /*
       * NO admitimos duplicados en esta implementacion.
       */

      if ( R > 0 )
         return;

      /*
       * Si no le encontramos, sabemos que el menor esta
       * en |R|
       */
      if ( R < 0 )
         R = -R;

      priv_agregar (pg.ptrMayor (R), d);

      /* 
       * Si el arbol no necesita crecer, simplemente retornar, pues
       * la operacion de agregar ya se completo.
       */

      if ( item_a_subir_dato == null )
         return;

      /* 
       * Si hay lugar en la pagina actual, agregar.
       */

      if ( pg.m < this.orden )
         agregar_sin_crecer (pg, R);
      else
         partir_pagina_y_agregar (pg, R);
   }


   /*
    * Rutina auxiliar de priv_agregar(), llamado cuando
    * hay lugar en la pagina actual para agregar un item.
    */

   private void agregar_sin_crecer (PaginaBArbol pg, int R)
   {
      pg.m++; 

      /*
       * Hacemos un lugar para el nuevo dato, en la posicion
       * correcta, basandonos en R (su primer menor).
       */
      for (int k=pg.m; k >= R+2; k--)
          pg.copiarItem (k, pg, k-1);

      pg.asignarItem (R+1, item_a_subir_dato, item_a_subir_ptr_may);

      /*
       * Indiquemos a quien nos haya llamado que el arbor no necesita
       * crecer.
       */

      item_a_subir_dato = null;
   }


   /*
    * Rutina auxiliar de priv_agregar(), llamado cuando
    * la pagina actual debe partirse.
    */

   private void partir_pagina_y_agregar (PaginaBArbol pg, int R)
   {
      /*
       * Tendremos que partir pg en 2, es decir, crearemos una
       * nueva pagina.
       */

      PaginaBArbol b = new PaginaBArbol (this.orden);
      int n = orden / 2;

      /*
       * Necesitamos hacer una copia de item_a_subir_xxx porque
       * insetaremos en una de estas dos paginas al item que esta
       * ¨flotando¨ pero (posiblemente) a consecuencia otro
       * item de la pagina actual dejaremos que flote hacia la raiz.
       */
      T          copia_item_a_subir_dato    = item_a_subir_dato;
      PaginaBArbol copia_item_a_subir_ptr_may = item_a_subir_ptr_may;

      if ( R <= n )
      {
         /*
          * Cuando R == n, quiere decir que todos los items a la
          * mitad izquierda son menores que el dato que esta
          * flotando, asi que no debemos correr nada; simplemente
          * copiar la mitad derecha en la nueva pagina y dejar
          * que siga flotando un nivel mas.
          */

         if ( R != n )
         {
            /*
             * El item que debe flotar es pg [n].
             * Notese que estamos sobreescribiendo el contenido
             * de item_a_subir_xxx, pero no nos importa porque
                * ya tenemos una copia en copia_item_a_subir_xxx.
             */
            item_a_subir (pg, n);

            /*
             * Hacemos lugar para el item que ¨floto¨ hasta nosotros.
             */
            for (int k=n; k >= R+2; k--)
                pg.copiarItem (k, pg, k-1);

            pg.asignarItem (R+1, copia_item_a_subir_dato, copia_item_a_subir_ptr_may);
         }
         /*
          * Copiamos la mitad derecha de pg en la mitad izquierda
          * de la nueva pagina.
          */
         for (int k=1; k <= n; k++)
             b.copiarItem (k, pg, k+n);
      }
      else
      {
         /*
          * En la nueva pagina habran n items menos que ahora, asi
          * que la posicion de insercion se desplaza a la izquierda
          * en igual cantidad.
          */
         R -= n;

         /*
          * Como consecuencia de la division, el item que debe flotar
          * es el primero de la mitad derecha.
          */
         item_a_subir (pg, n+1);

         /*
          * Copiamos a la nueva pagina todos los item que estan
          * antes de R. NO copiamos pg [n+1].
          */
         for (int k=1; k < R; k++)
             b.copiarItem (k, pg, k+n+1);
            
         b.asignarItem (R, copia_item_a_subir_dato,
                           copia_item_a_subir_ptr_may);

         /*
          * Copiamos a la nueva pagina los elementos que estaban
          * a la derecha de R en la vieja pagina (pg).
          */
         for (int k=R+1; k <= n; k++)
             b.copiarItem (k, pg, k+n);
      }
      /*
       * Tanto la vieja como la nueva pagina quedaron con n
       * items.
       */

      pg.m = n;
      b.m = n;

      /*
       * La nueva pagina que hemos creado contiene elementos que
       * son todos mayores que pg [n+1] (dato original), por lo tanto
       * su apuntador a menores (may [0]) es el que correspondia
       * a pg [n+1].
       */

      b.may.set(0, item_a_subir_ptr_may);

      /*
       * Ya hemos registrado cual es el item que debe flotar hacia
       * la raiz. El puntero ¨derecho¨ de este item 
       * debe ser actualizado: su ptr_may debe apuntar ahora a la
       * pagina que acabamos de crear.
       */

      item_a_subir_ptr_may = b;
   }


   public void imprimir()
   {
      priv_imprimir (raiz, 0);
   }


   void priv_imprimir (PaginaBArbol pg, int nivel)
   {
      int k;

      if ( pg == null )
         return;

      for (k=0; k < nivel; k++)
          System.out.print (" ");

      for (k=1; k <= pg.m; k++)
      {
          System.out.print( pg.dato.get(k) + " " );
          System.out.print (" ");
      }
      System.out.print("  ");

      for (k=0; k <= pg.m; k++)
         priv_imprimir (pg.ptrMayor (k), nivel + 1);
   }

   public void imprimirAsc(){
        priv_imprimir_asc(raiz);
   }


   private void priv_imprimir_asc (PaginaBArbol pg)
   {
      if ( pg == null )
         return;

      priv_imprimir_asc (pg.ptrMayor (0));
      for (int k=1; k <= pg.m; k++) {
          System.out.print( pg.dato.get(k) + " " );
          System.out.print ("-");
          priv_imprimir_asc (pg.ptrMayor (k));
      }
      System.out.println();
   }
   public int eliminar(ArrayList<T>A ){
	   
		int i,j,k;
		int match = 0;
  
		Scanner scan = new Scanner(System.in);
			
		System.out.println("Inserte el elemento a eliminar");
		String aux = scan.nextLine();
		System.out.println("El caracter a borrar es = "+aux);
		for (j = 0; j< A.size();j++){
			if(aux.compareTo(String.valueOf(A.get(j))) == 0){
				System.out.println("El caracter encontrado es = "+A.get(j));
				match = 1;
				for(k = j; k < A.size() - 1; k++)
					A.set(k,A.get(k+1));
					A.remove(A.size()-1);
				break;
			}
		}
		return match;
   }
    

   public T buscar (T d)
   {
       return ( priv_buscar (raiz, d) );
   }


   private T priv_buscar (PaginaBArbol pg, T d)
   {
       int R;

       if ( pg == null )
          return ( null );

       R = pg.buscar (d);
       if ( R > 0 )
          return ( pg.dato.get(R) );

       return ( priv_buscar (pg.ptrMayor (-R), d) );
   }

 
   
   /*
     * PaginaBArbol.java
     * 
     * Implementa una pagina de un B-Arbol, con cantidad configurable
     * de items por pagina.
     *
     * 
     */
    
    /*
     * Entero se importa solo porque main() lo utiliza para probar
     * esta clase.
    */
    
    /**
     * Implementa una pagina de B-Arbol.
     * Cada pagina contiene:
     * 1. Un arreglo de referencias al dato (dato[]), que debe ser derivado de
     *    la interfaz Cmp, directa o indirectamente.
     *    Este arreglo tiene orden+1 elementos, aunque solo se usan los
     *    elementos de 1..orden. (El elemento 0 se desperdicia para
     *    mantener coherencia con may[], que si usa el elemento 0).
     * 2. Un arreglo de referencias a la pagina que contiene datos mayores
     *    que la pagina actual (may[]).
     * 3. Un contador de elementos en uso (m).
     *
     * La implementacion tradicional es combinar dato y may en una
     * estructura y utilizar un solo arreglo. Sin embargo, esta
     * estructura es simple y muy facil de entender.
     *
     * 
    */
    
    public  class PaginaBArbol
    {
       public int m;
       public ArrayList<T> dato;
       public ArrayList<PaginaBArbol> may;

		
       public PaginaBArbol(int orden)
       {
          dato = new ArrayList<T>(orden + 1);
          may = new ArrayList<>(orden + 1);
          m = 0;
		  for (int i = 0; i < orden + 1; i++){
			dato.add(null);
			may.add(null);
		  }
          for (int k=0; k <= m; k++)
              asignarItem (k, null, null); 
       }
    
       public PaginaBArbol ptrMayor (int p)
       {
          return ( may.get(p) );
       }
    
    
       public  void insertar (T d)
       /**
          Se parte de la premisa de que venimos aqui solo
          si la pagina no esta llena.
       */
       {
          //int cmp;
          int k;
          
          /*
          if ( m >= dato.length )
             throw new Exception ("PaginaBArbol llena");
          */
    
          ++m;
         
          for (k=m; k > 1; k--)
          {
              if (d.compareTo(dato.get(k-1)) >= 0)
                 break;
    
              dato.set(k, dato.get(k-1));
              may.set(k,may.get(k-1));
          }
          dato.set(k,d);
          may.set(k,null);
       }
    
    
       /**
          Retorna posicion de un elemento, indicado por retorno > 0.
    
          Si d no se encuentra, retorna posicion del elemento
          menor, cambiado de signo (por ejemplo, -3 para indicar
          que en la posicion 3 esta un elemento menor a d).
       */
       public int buscar (T d)
       {
          int R, L;
          int i = 0;
		 
          L = 1;
          R = m+1;
          
		  while ( L < R )
          {
             i = (L+R) / 2;
   
             if (dato.get(i).compareTo(d) == 0 )
                break;
    
             if ( dato.get(i).compareTo(d) < 0 )
                L = i + 1;
             else
                R = i;
          }
          if ( dato.get(i).compareTo(d) == 0 )
             return ( i );
          else
            return ( - (R-1) );
       }
		

       public void eliminar (int p)
       {
          if ( m == 0 )
             return;
    
          for (int k=p; k < m; k++) 
          {
              dato.set(k,dato.get(k+1));
              may.set(k,may.get(k+1));
          }
          dato.set(m,null);
          --m;
       }
       
       public void imprimir()
       {
          System.out.println();
    
          for (int k=1; k <= m; k++)
          {
              System.out.print( dato.get(k) + " " );
              System.out.print ("(" + k + ") ");
          }
       }
    
       public void asignarItem(int pos_dest, T d,PaginaBArbol ptr_may)
		{
          this.dato.set(pos_dest,d) ;
          this.may.set(pos_dest, ptr_may);
       }
       
    
       public void copiarItem (int pos_dest, PaginaBArbol b, int pos_orig)
       {
          this.dato.set(pos_dest, b.dato.get(pos_orig));
          this.may.set(pos_dest,b.may.get(pos_orig));
       }
    
    }
	
	
   public static void main(String [] argv) {
     
		ArrayList<Integer> A = new ArrayList<Integer>();	
		A.add(13);
		A.add(42);
		A.add(4);
		A.add(6);
		A.add(20);
		A.add(15);
		A.add(45);
		A.add(44);
		A.add(56);
		A.add(36);
		A.add(55);
		A.add(78);
		
	   Scanner scan = new Scanner(System.in);
	   
	   int choice = 1;
	   int i,item = 0;
	   int start = 1;
	   int elOrden;
	   long t1 ,t2;
	   long t_barb_ins,t_barb_bus;
	   System.out.println("Inserte un numero entero positivo para el orden del arbol");
	   elOrden = scan.nextInt();
 
	   BArbol <Integer> t = new BArbol<Integer>(elOrden);
	  
		for (i=0;i<A.size();i++){
			t.agregar(A.get(i));
		}
			
		t.imprimirAsc();
	   
	   while(choice == 1 ){
			
			System.out.println("BArbol\n1)Eliminar un elemento del BArbol\n2Cuadro de Comparacion");
				
			choice = scan.nextInt();
			scan.nextLine();
					
			if(choice == 1){
				item = t.eliminar(A);
				System.out.println("El archivo fue encontrado: "+item);

				if(item == 1){
					t = new BArbol<Integer>(elOrden);
					for (i=0;i<A.size();i++){
						t.agregar(A.get(i));
					}
					t.imprimirAsc();
				}
			}
			else if(choice == 2){
				t1 = System.currentTimeMillis();
				
					t = new BArbol<Integer>(4);
					for (int g = 1000000;g>0;g--){
						Integer hello = g;
						t.agregar(hello);
					}
		
				t2 =  System.currentTimeMillis();
				
				t_barb_ins = t2 - t1; 
				
				t1 = System.currentTimeMillis();
				
					t = new BArbol<Integer>(4);
					for (int g = 1000000;g>0;g--){
						Integer hello = g;
						t.buscar(hello);
					}
		
				t2 =  System.currentTimeMillis();
				
				t_barb_bus = t2 - t1; 
			
				System.out.println("\t\tB-Arbol");
				System.out.println("\tInsertar\t\tBuscar");
				System.out.println("\t"+t_barb_ins+"\t\t\t"+t_barb_bus);
			
			}
		}
	}
}	
		
