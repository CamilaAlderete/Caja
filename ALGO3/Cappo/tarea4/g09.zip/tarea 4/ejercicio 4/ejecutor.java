
/*
    Eric Ruiz Diaz
    Ruben Izembrandt
    G 09
*/
public class ejecutor {  
    public static void main(String [] args){
        
        //Comentar los tests 2 y 3 para ejecutar el 1
        //Comentar los tests 1 y 3 para ejecutar el 2
        //Comentar los tests 1 y 2 para ejecutar el 3
                //test 1
		Nodo test=new Nodo(2);
		test.anadir(test, 0);
		test.anadir(test, 1);
		test.anadir(test, 3);
		test.anadir(test, 5);
		test.imprimir(test);
		test.antecesor(test,3);
		System.out.println("El antecesor a 3 es "+ test.menor);
		test.sucesor(test,3);
		System.out.println("El sucesor a 3 es "+ test.mayor);
                test.cntHojas(test);
                System.out.println("La cantidad de hojas es "+test.ctnNodos);
                
                //test 2
                Nodo test2=new Nodo(15);
		test2.anadir(test2, 6);
		test2.anadir(test2, 18);
		test2.anadir(test2, 3);
		test2.anadir(test2, 7);
                test2.anadir(test2, 17);
                test2.anadir(test2, 20);
                test2.anadir(test2, 2);
                test2.anadir(test2, 4);
                test2.anadir(test2, 13);
                test2.anadir(test2, 9);
                
		test2.imprimir(test2);
		test2.antecesor(test2,3);
		System.out.println("El antecesor a 3 es "+ test2.menor);
		test2.sucesor(test2,3);
		System.out.println("El sucesor a 3 es "+ test2.mayor);
                test2.cntHojas(test2);
                System.out.println("La cantidad de hojas es "+test2.ctnNodos);
                
                //test 3
                Nodo test3=new Nodo(2);
		test3.anadir(test3, 12);
		test3.anadir(test3, 32);
		test3.anadir(test3, 5);
		test3.anadir(test3, 9);
		test3.imprimir(test3);
		test3.antecesor(test3,9);
		System.out.println("El antecesor a 9 es "+ test3.menor);
		test3.sucesor(test3,3);
		System.out.println("El sucesor a 9 es "+ test3.mayor);
                test3.cntHojas(test3);
                System.out.println("La cantidad de hojas es "+test3.ctnNodos);
    }
}
