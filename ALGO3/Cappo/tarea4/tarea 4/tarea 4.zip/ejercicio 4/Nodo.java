
/*
    Eric Ruiz Diaz
    Ruben Izembrandt
    G 09
*/
public class Nodo{
    //Atributos
        Comparable <Integer> valor;       
        Nodo left;
        Nodo right;
    public static int menor;
    public static int mayor;
    public static int ctnNodos;
    
    //Constructor
    Nodo(Comparable <Integer> dato){
        this.valor=dato;
        this.left=null;
        this.right=null;
    }
    //Setters y getters
    public Nodo getLeft(Nodo nodo){    
        return this.left;   
    }
    public Nodo getRight(Nodo nodo){    
        return this.right;   
    }
    public Comparable <Integer> getValor(Nodo nodo){    
        return this.valor;   
    }
    
    public void setValor(Comparable <Integer> valor){
        this.valor=valor;
    }
    
    public void setLeft(Nodo nodo){    
        this.left=nodo;   
    }
    public void setRight(Nodo nodo){    
        this.right=nodo;   
    }
    
    public void anadir(Nodo raiz,Comparable <Integer> dato){    
        Nodo mov=raiz;                                                          //1
        
		while(mov.left!=null || mov.right!=null){                       //n+1
		//System.out.println("While"+"-Cabeza:"+mov.valor);
                    if((int)dato>(int)mov.valor && mov.right!=null){                      //n
			//System.out.println("IF"+"-Dato:"+dato);            
			mov=mov.right;
                    }else if ((int)dato<(int)mov.valor && mov.left!=null){                //n
                        //System.out.println("ELSE IF"+"-Valor:"+dato);
			mov=mov.left;                                           //n
                    }else{
			//System.out.println("BREAK"+"-Valor:"+dato);
			break;
		}
        }
        
        Nodo agr = new Nodo(dato);                                              //1
        
        //System.out.println(mov.valor+"Ponision - "+agr.valor);
        if((int)dato>(int)mov.valor){                                                     //1
            mov.right=agr;                                                      //1
        }else{
            mov.left=agr;                                                       //1
        }
        
    }
        /*La funcion anadir esta en O(n)*/
    public void eliminar(Comparable <Integer> dato){
    
    }
    
    public boolean esLleno(){
        
        return false;
    
    }
    
    public boolean esCompleto(){
        return false;
    
    }
    
    public int cntHojas(Nodo raiz){
        if(raiz.right==null && raiz.left==null){                                //1
            //System.out.println("Caso base");
            ctnNodos=1;                                                         //1
            
        }else{
            if(raiz.left!=null){                                                //1
                //System.out.println("Caso 1");
                ctnNodos=ctnNodos+cntHojas(raiz.left);                          //log(2,n)
            }
            if(raiz.right!=null){                                               //1
                //System.out.println("Caso 2"); 
                ctnNodos=ctnNodos+cntHojas(raiz.right);                         //log(2,n)
            }    
        
        }   
        return ctnNodos;
    }
    /*La funcion ctnHojas esta en log de base 2 de n*/

   public void antecesor(Nodo n_actual, Comparable <Integer> dato){
        if ( n_actual != null ){                                                        //1
            antecesor(n_actual.left,dato);                                              //log(2,n)
            if ((int)n_actual.valor<(int)dato){                                         //1
		menor = (int) n_actual.valor;                                           //1
		//System.out.println("Se encontro que "+ menor +" es menor a "+ dato);
            }
            antecesor (n_actual.right,dato);                                            //log(2,n)
	}
   }
   /*La funcion antecesor esta en O(log(2,n))*/
   
    public void sucesor(Nodo n_actual, Comparable <Integer> dato){
        if ( n_actual != null ){                                                        //1 
            sucesor(n_actual.left,dato);                                                //log(2,n)
        if (n_actual.valor == dato){                                                    //1
            mayor = (int)n_actual.right.valor;                                          //1
            //System.out.println("Se encontro que "+ mayor +" es mayor a "+ dato);
        }			
        sucesor (n_actual.right,dato);                                                  //log(2,n)
	}
   }
    /*La funcion sucesor esta en O(log(2,n))*/

    public void imprimir (Nodo n_actual){
      if ( n_actual != null ){
         imprimir (n_actual.left);
         System.out.print (n_actual.valor + " ");
         imprimir (n_actual.right);
      }
   }
}