
import java.util.concurrent.ThreadLocalRandom;
/*
    Eric Ruiz Diaz
    Ruben Izembrandt
    G 09
*/
public class arregloBST {
    
    private class NodoBST {
      	  int dato;
	NodoBST izq = null;
	NodoBST der = null;

	public NodoBST (int dato){
            this.dato = dato;
        }
    }
   
    private NodoBST raiz = null;
    public static int indice = 0;
    public static int[] miVector;
    
    public void CargarVector(int size){
        int i;
        miVector = new int[size];
        for(i = 0; i< miVector.length; i++){
            miVector[i]= ThreadLocalRandom.current().nextInt(100, 10000);
        }

    }
    public void cargarDatoVector(int dato, int cant){
        if(indice<cant){
            miVector[indice] = dato;
            indice++;
        }
    }
    public void imprimirVector(int array[],int cant){
        for( int i = 0; i< cant; i++){
            System.out.printf( array[i] + " ");
        }
         System.out.printf("\n");
    }
     
    public void cargarArbol (int dato){
        raiz = priv_agregar (raiz, dato);
    }

   private NodoBST priv_agregar (NodoBST n_actual, int dato){
        if ( n_actual == null ) {
            return ( new NodoBST(dato) );
        }
        Comparable <Integer> valor = dato;
        int comparacion = valor.compareTo ( n_actual.dato);
	 
		if ( comparacion < 0 ) { 
            n_actual.izq = priv_agregar(n_actual.izq,dato);
        } else {
            n_actual.der = priv_agregar(n_actual.der,dato);
        }
		 
	return n_actual;
	 
   }
      private void recorrerInOrden (NodoBST n_actual, int cant){
      if ( n_actual != null ) { 
         recorrerInOrden(n_actual.izq,  cant);
         cargarDatoVector(n_actual.dato,cant);
         recorrerInOrden(n_actual.der, cant);
      }
   }
   
    private void imprimirInOrden (NodoBST n_actual){
      if ( n_actual != null ){ 
         imprimirInOrden(n_actual.izq);
         System.out.printf(n_actual.dato + " ");
         imprimirInOrden(n_actual.der);
      }
   }
   
    public static void main ( String [] args ) {
        int size = 0;
        long t;
        long t1, t2;
        double tn2;
        double tn;
        double nlogn; 
        
        System.out.println("|\t N\t|  T(n) en ms\t|      T/N\t| T/(N log, N )\t|\tT/N^2\t     |");
        System.out.println("--------------------------------------------------------------------------------------");
        for(int i = 0; i < args.length; i++){
            indice = 0;    
            size = Integer.parseInt(args[i]);
            arregloBST objeto = new arregloBST();
            objeto.CargarVector(size);

            
			t1 = System.currentTimeMillis();
            for ( int k=0; k < miVector.length; k++ ){
                objeto.cargarArbol(miVector[k]);
            }
            objeto.recorrerInOrden(objeto.raiz, size);
            t2 = System.currentTimeMillis();
			
			
            t = t2-t1;
            tn = (double)t/size;
            nlogn =(double) (t)/(size * (Math.log(size)/Math.log(2)));
            tn2 = (double)(t / (size * size));
            System.out.printf("|\t%d\t|\t%d\t|   %.6f    |   %.6f    |   %.14f",size,t,tn , nlogn , tn2  );
            System.out.println(" |");
        }
    
    }
}
